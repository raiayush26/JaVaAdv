// Ayush
// 20Bce10938

interface GCD
{
    void abstractFun(int n1,int n2);

    default int normalFun(int n1,int n2)
    {
        int i;
        if (n1 < n2)
            i = n1;
        else
            i = n2;
 
      
        for (i = i; i > 1; i--) {
 
            
            if (n1 % i == 0 && n2 % i == 0)
                return i;
    }
}
  
class CAT2a
{
    public static void main(String args[])
    {
        
        GCD fobj = (int n1,int n2)->System.out.println("GCD = " + gcd(n1 , n2));
  
        fobj.abstractFun(2,4);
    }
}